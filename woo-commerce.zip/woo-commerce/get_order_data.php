<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://woo-bravely-candid-miracle7.wpcomstaging.com/wp-json/wc/v3/orders?consumer_key=ck_7260e392f1e5c6f8e781bd9e51043a78fb891979&consumer_secret=cs_0919badb6e66eac412084c7502fe14d4fc9d84d2',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Cookie: mailpoet_page_view=%7B%22timestamp%22%3A1702298877%7D'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
$decode= json_decode($response);
/*echo $response;*/
echo "<pre>";
print_r($decode);
echo "</pre>";
?>